# phishing-attack-insta-facebook
A Express app for Phishing user and get the instagram and facebook password of the users 
with the Mongodb database to store data 

- [x] *Education purpose only*
